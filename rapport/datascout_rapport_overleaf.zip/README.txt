DataScout - Rapport final LaTeX

Pour utiliser sur Overleaf :
1. Décompressez le fichier ZIP.
2. Importez le dossier dans Overleaf.
3. Ouvrez main.tex.
4. Compilez avec pdfLaTeX.
